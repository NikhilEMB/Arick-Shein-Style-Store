import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Events, LoadingController, AlertController, ActionSheetController, ModalController } from '@ionic/angular';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { ImageModalPage } from 'src/app/image-modal/image-modal.page';

@Component({
  selector: 'app-add-brand',
  templateUrl: './add-brand.page.html',
  styleUrls: ['./add-brand.page.scss'],
})
export class AddBrandPage implements OnInit {
  status = true;
  name = '';
  image = [];
  banner = [];
  brandData: any;
  brandId = '';
  loading: any;
  sortedAt: any;
  constructor(private router: Router,
              private events: Events,
              private loadingController: LoadingController,
              public alertController: AlertController,
              private camera: Camera,
              private actionSheetController: ActionSheetController,
              private route: ActivatedRoute,
              private modalController: ModalController) {
      this.route.queryParams.subscribe(params => {
        if (this.router.getCurrentNavigation().extras.state) {
          this.brandData = this.router.getCurrentNavigation().extras.state.brandData;
          if (this.brandData) {
            this.name = this.brandData.name;
            this.status = this.brandData.status;
            this.image = this.brandData.image.hasOwnProperty('url') ? [{...this.brandData.image}] : [];
            this.banner = this.brandData.banner.hasOwnProperty('url') ? [{...this.brandData.banner}] : [];
            this.brandId = this.brandData.id;
            this.sortedAt = this.brandData.sortedAt;
          }
        }
      });
    }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.initializeSubscriptions();
  }
  ionViewWillLeave() {
    this.removeSubscriptions();
  }

  initializeSubscriptions() {
    this.events.subscribe('brands:saveBrandSuccess', () => {
      this.loading.dismiss();
      this.presentAlert('Brand Saved Successfully', true);
    });
    this.events.subscribe('brands:deleteBrandSuccess', () => {
      if (this.loading) {
        this.loading.dismiss();
      }
      this.presentAlert('Brand deleted successfully!', true);
    });
  }

  async saveBrand() {
    if (!this.name) {
      this.presentAlert('Please enter brand name');
    } else {
    await this.presentLoading('Saving brand details...', 10000);
    const brandData = {
      name: this.name,
      status: this.status
    };
    brandData['sortedAt'] = this.brandId ? this.sortedAt : new Date();
    this.events.publish('brands:saveBrand', brandData, this.image, this.banner, this.brandId);
  }
}
updateStatus() {
  this.status = !this.status;
}

removeImage(type: string) {
  if (type === 'brandImg') {
    this.image.splice(0, 1);
  } else {
    this.banner.splice(0, 1);
  }
}

async deleteConfirm() {
  const alert = await this.alertController.create({
    message: 'Are you sure you want to delete this brand?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        cssClass: 'secondary',
        handler: (blah) => {
          console.log('Confirm Cancel: blah');
        }
      }, {
        text: 'Delete',
        handler: () => {
          console.log('Confirm Okay');
          this.deleteBrand();
        }
      }
    ]
  });

  await alert.present();
}
async deleteBrand() {
  await this.presentLoading('Deleting brand...', 5000);
  this.events.publish('brands:deleteBrand', this.brandId);
}



async imageActionSheet(type: string) {
  const actionSheet = await this.actionSheetController.create({
    header: 'Select any option',
    buttons: [{
      text: 'Camera',
      icon: 'camera',
      handler: () => {
        this.addCameraImage('camera', type);
      }
    }, {
      text: 'Gallery',
      icon: 'images',
      handler: () => {
        this.addCameraImage('gallery', type);
      }
    }, {
      text: 'Cancel',
      icon: 'close',
      role: 'cancel',
      handler: () => {
        console.log('Cancel clicked');
      }
    }]
  });
  await actionSheet.present();
}
addCameraImage(ctype: string, type: string) {
  const optionsforCamera: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    correctOrientation : true,
    allowEdit: true
  };
  if (ctype === 'gallery') {
    optionsforCamera['sourceType'] = 0;
  }
  this.camera.getPicture(optionsforCamera).then((imageData) => {
    const base64Image = 'data:image/jpeg;base64,' + imageData;
    if (type === 'brandImg') {
      this.banner = [];
      this.banner.push({url: base64Image});
    } else {
      this.image = [];
      this.image.push({url: base64Image});
    }
   }, (err) => {
    console.log(err);
  });
}

uploadImage(files: FileList, type) {
  console.log(type);
  for (let i = 0; i < files.length; i++) {
    let reader = new FileReader();
    reader.readAsDataURL(files.item(i))
    reader.onload = (event:any) => { // called once readAsDataURL is completed
      let base64Image:any = event.target.result;
      let base64Str = base64Image.split(',');
      //let size = this.calculateImageSize(base64Str[1]);
      //this.imageResponse.push({imgData: base64Image, imgSize: size});
      if (type === 'brandImg') {
      this.image = [];
      this.image.push({url: base64Image});
    } else {
      this.banner = [];
      this.banner.push({url: base64Image});
    }
   
    }
  }
}

imgZoom(img: any) {
  this.modalController.create({
    component: ImageModalPage,
    cssClass:'photo-modal-class',
    componentProps: {
      imgs: [{url: img}],
      index: 0
    }
  }).then(modal => modal.present());
}

async presentAlert(msg: string, action?: boolean) {
  const alert = await this.alertController.create({
    message: msg,
    buttons: [{
      text: 'OK',
      handler: () => {
        if (action) {
          this.router.navigate(['all-brands']);
        }
      }
    }]
  });
  await alert.present();
}

async presentLoading(msg: string, drn: number) {
  this.loading = await this.loadingController.create({
    message: msg,
    duration: drn
  });
  await this.loading.present();
}


  removeSubscriptions() {
    this.events.unsubscribe('brands:saveBrandSuccess');
    this.events.unsubscribe('brands:deleteBrandSuccess');

    this.events.publish('brands:removeBrandsSubs');
  }

}
